using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MoviesOnDemandSC.MoviesOnDemandWS;

namespace MoviesOnDemandSC
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            this.usernameText.Focus();
        }

        public MoviesOnDemandWS.Account UserAccount = new MoviesOnDemandSC.MoviesOnDemandWS.Account();
        public bool CancelStatus = false;

        private void loginButton_Click(object sender, EventArgs e)
        {
            if (this.usernameText.Text.Trim() != string.Empty && this.passwordText.Text.Trim() != string.Empty)
            {
                MoviesOnDemandWS.MoviesOnDemand mod = new MoviesOnDemandWS.MoviesOnDemand();
                MoviesOnDemandWS.AuthenticateRequest request = new MoviesOnDemandSC.MoviesOnDemandWS.AuthenticateRequest();
                request.Username = this.usernameText.Text.Trim();
                request.Password = this.passwordText.Text.Trim();

                try
                {
                    //Make the authentication call to the web service. For demonstration purposes, no security has been implemented on this
                    //call (the demo all runs on one machine). In a real application, these credentials should be encrypted and the service
                    //locked down using WSE.
                    MoviesOnDemandWS.AuthenticateResponse response = mod.Authenticate(request);

                    //The Result member on the AuthenticateResponse message give an immediate status of the login attempt.
                    if (response.Result)
                    {
                        this.UserAccount = response.Account;
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Sorry, the username and password you entered were not found. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                catch (System.Web.HttpException ex)
                {
                    MessageBox.Show("An error occured while trying to connect to the authentication web service. Here are the details of the error:\n\n" + ex.Message + "\n" + ex.Source + "\n" + ex.StackTrace, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                catch (System.Web.Services.Protocols.SoapException ex)
                {
                    MessageBox.Show("An error occured while processing your login with the authentication service. Here are the details of the error:\n\n" + ex.Message + "\n" + ex.Source + "\n" + ex.StackTrace, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                catch (Exception ex)
                {
                    MessageBox.Show("An error occured while trying to log you in. Here are the details of the error:\n\n" + ex.Message + "\n" + ex.Source + "\n" + ex.StackTrace, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please make sure you've entered a username and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Login_Leave(object sender, EventArgs e)
        {
            this.CancelStatus = true;
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.CancelStatus = true;
        }
    }
}