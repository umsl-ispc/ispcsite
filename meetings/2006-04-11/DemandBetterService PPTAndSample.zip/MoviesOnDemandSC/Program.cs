using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MoviesOnDemandSC
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Login login = new Login();
            login.ShowDialog();

            if (login.CancelStatus)
            {
                Application.Exit();
            }
            else
            {
                Application.Run(new Form1(login.UserAccount));
            }
        }
    }
}