using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MoviesOnDemandSC.MoviesOnDemandWS;
using System.IO;

namespace MoviesOnDemandSC
{
    public partial class Form1 : Form
    {
        public Form1(MoviesOnDemandWS.Account account)
        {
            _userAccount = account;
            InitializeComponent();
        }

        private MoviesOnDemandWS.Account _userAccount = new MoviesOnDemandSC.MoviesOnDemandWS.Account();
        private Movie[] _movies = new Movie[0];

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                //Populate the welcome label at the top of the main form. For this demo, this is primarily to ensure we have authenticated correctly.
                this.welcomeLabel.Text = "Enjoy the show, " + _userAccount.Customer.FirstName + " " + _userAccount.Customer.LastName;
            }

            catch (NullReferenceException ex)
            {
                this.welcomeLabel.Text = "Customer's first and last name not found!";
            }

            //Instantiate the objects that will be involved in getting the movie data from the web service
            MoviesOnDemand mod = new MoviesOnDemand();
            GetMovieRequest request = new GetMovieRequest();
            request.MovieID = string.Empty;
            request.GetAll = 1;

            try
            {
                GetMovieResponse response = mod.GetMovie(request);

                if (response.Movie.Length > 0)
                {
                    this._movies = response.Movie;

                    //Since we received an array of Movie objects from the web service, loop through the array and load the title list into the ListBox control
                    foreach (Movie movie in response.Movie)
                    {
                        this.movieListBox.Items.Add(movie.Title);
                    }
                }
                else
                {
                    this.movieListBox.Items.Add("No movies available");
                }
            }

            
            catch (Exception ex)
            {
                //TODO: Add loggin routine
                MessageBox.Show("The following error took place while try to load the movie list:\n" + ex.Message + "\n" + ex.Source + "\n" + ex.StackTrace, "Error", MessageBoxButtons.OK);
            }
        }

        private void movieListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            Movie selectedMovie = this.getSelectedMovie();
            if (selectedMovie.ID != string.Empty)
            {
                //Apply the member data to the UI controls
                this.titleLabel.Text = selectedMovie.Title;
                this.directorLabel.Text = selectedMovie.Director.FirstName + " " + selectedMovie.Director.LastName;
                DateTime releaseDate = DateTime.Parse(selectedMovie.DateOfRelease);
                this.releaseDateLabel.Text = releaseDate.ToShortDateString();

                //Pull the image of the movie poster out of the byte array and apply it to the PictureBox control
                MemoryStream stream = new MemoryStream(selectedMovie.PosterImage);
                this.pictureBox1.Image = System.Drawing.Image.FromStream(stream);
            }
        }

        /// <summary>
        /// Since the collection of available movies is stored in memory on the client machine, this routine loops through the current
        /// collection and determines which of the movies in the list has been selected by the use and returns a Movie object with that
        /// specific movie's data
        /// </summary>
        /// <returns>Returns a Movie object with the selected movie's data populated</returns>
        private Movie getSelectedMovie()
        {
            Movie selectedMovie = new Movie();

            foreach (Movie movie in this._movies)
            {
                if (this.movieListBox.Text == movie.Title)
                {
                    selectedMovie = movie;
                    break;
                }
            }

            return selectedMovie;
        }

        private void playButton_Click(object sender, EventArgs e)
        {
            Movie selectedMovie = this.getSelectedMovie();

            //This assumes that the URL for the movies is in the local instance of IIS. For demonstration purposes, this was
            //hard-coded into the application. For more practical use, it should be moved to a config file.
            this.axWindowsMediaPlayer1.URL = "http://localhost/Movies/" + selectedMovie.FileName;
        }


        private void stopButton_Click(object sender, EventArgs e)
        {
            this.axWindowsMediaPlayer1.URL = string.Empty;
        }
    }
}