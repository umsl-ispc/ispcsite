using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MoviesOnDemandWS;
using System.Text;

public partial class MovieList : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //TODO: REMOVE THIS WHEN DONE DEBUGGING
            //Application["MovieList"] = null;
            this.checkCache();

            Movie[] movies = (Movie[])Application["MovieList"];

            this.loadPlayer(string.Empty);

            if (movies.Length > 0)
            {
                foreach (Movie movie in movies)
                {
                    this.movieListBox.Items.Add(new ListItem(movie.Title, movie.ID));
                }
            }
            else
            {
                this.movieListBox.Items.Add(new ListItem("No movies found", string.Empty));
            }
        }


        
    }
    
    protected void movieListBox_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.checkCache();

        this.moviePoster.Visible = true;

        Movie selectedMovie = this.getSelectedMovie();

        try
        {
            this.titleLabel.Text = selectedMovie.Title;
            this.directorLabel.Text = selectedMovie.Director.FirstName + " " + selectedMovie.Director.LastName;
            this.releaseDateLabel.Text = selectedMovie.DateOfRelease;

            this.moviePoster.ImageUrl = "GetImage.aspx?id=" + selectedMovie.ID;
        }

        catch (System.NullReferenceException ex)
        {
        }
    }

    private Movie getSelectedMovie()
    {
        Movie[] movies = (Movie[])Application["MovieList"];
        Movie selectedMovie = new Movie();

        foreach (Movie movie in movies)
        {
            if (movie.ID == this.movieListBox.SelectedValue)
            {
                selectedMovie = movie;
                break;
            }
        }
        return selectedMovie;
    }

    private void checkCache()
    {
        //If the cache has expired, then reload it
        if (Application["MovieList"] == null)
        {
            MoviesOnDemand mod = new MoviesOnDemand();
            GetMovieRequest request = new GetMovieRequest();
            request.MovieID = string.Empty;
            request.GetAll = 1;

            GetMovieResponse response = mod.GetMovie(request);

            Application["MovieList"] = response.Movie;
        }
    }

    private void loadPlayer(string fileName)
    {
        StringBuilder sb = new StringBuilder();

        sb.Append("<OBJECT ID=\"MediaPlayer\" WIDTH=\"450\" HEIGHT=\"369\" CLASSID=\"CLSID:22D6F312-B0F6-11D0-94AB-0080C74C7E95\" ");
        sb.Append("STANDBY=\"Loading Windows Media Player components...\" TYPE=\"application/x-oleobject\">");
        sb.Append("<PARAM NAME=\"FileName\" VALUE=\"http://localhost/Movies/").Append(fileName).Append("\">");
        sb.Append("<PARAM name=\"ShowControls\" VALUE=\"true\">");
        sb.Append("<PARAM name=\"ShowStatusBar\" value=\"false\">");
        sb.Append("<PARAM name=\"ShowDisplay\" VALUE=\"false\">");
        sb.Append("<PARAM name=\"autostart\" VALUE=\"true\">");
        sb.Append("<EMBED TYPE=\"application/x-mplayer2\" SRC=\"http://localhost/Movies/").Append(fileName).Append("\" NAME=\"MediaPlayer\" WIDTH=\"450\" HEIGHT=\"369\" ShowControls=\"1\" ShowStatusBar=\"0\" ShowDisplay=\"0\" autostart=\"0\"></EMBED>");
        sb.Append("</OBJECT>");

        this.playerLiteral.Text = sb.ToString();
    }
    protected void playMovieButton_Click(object sender, EventArgs e)
    {
        this.checkCache();
        Movie selectedMovie = this.getSelectedMovie();
        this.loadPlayer(selectedMovie.FileName);
    }
}
