using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MoviesOnDemandWS;

public partial class LoginControl : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void loginButton_Click(object sender, EventArgs e)
    {
        MoviesOnDemand mod = new MoviesOnDemand();
        AuthenticateRequest request = new AuthenticateRequest();
        AuthenticateResponse response = null;

        request.Username = this.usernameText.Text.Trim();
        request.Password = this.passwordText.Text.Trim();

        try
        {
            response = mod.Authenticate(request);

            //If the Result member of AuthenticateResponse message is equal to 'true,' then put the user's account information into
            //ASP.NET session and redirect to the movie view page.
            if (response.Result)
            {
                Session["Account"] = response.Account;
                Response.Redirect("ViewMovies.aspx", true);
            }
            else
            {
                this.messageLabel.Text = "Sorry, the username and password you entered could not be found. Please try again.";
            }
        }

        catch (System.Web.HttpException ex)
        {
            this.messageLabel.Text = "An error took place while contacting the authentication service. Please try again later.";
            //TODO: Add logging routine here
        }

        catch (System.TimeoutException ex)
        {
            this.messageLabel.Text = "Your login request has timed out. Please try again later.";
            //TODO: Add logging routine here
        }

        catch (Exception ex)
        {
            this.messageLabel.Text = "We're sorry, an error took place while trying to log into your account. Please try again later.<br>" + ex.Message + "<br>" + ex.Source + "<br>" + ex.StackTrace;
            //TODO: Add logging routine here
        }
    }
}
