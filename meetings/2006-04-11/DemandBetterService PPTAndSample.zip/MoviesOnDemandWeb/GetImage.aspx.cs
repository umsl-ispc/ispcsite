using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MoviesOnDemandWS;


public partial class GetImage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request["id"] != null)
            {
                //This routine queries the web service for a specific movie so the byte array of the movie poster can be rendered to the
                //Image control in the UI via the Response.BinaryWrite() method.

                //TODO: Refactor this section to look for the same data stored in the Application level cache. Be sure to remove any
                //redundant code from the application, i.e. find a way to reuse the routines already written to do this work!
                MoviesOnDemand mod = new MoviesOnDemand();
                GetMovieRequest request = new GetMovieRequest();
                request.MovieID = Request["id"].ToString();
                request.GetAll = 0;

                GetMovieResponse response = mod.GetMovie(request);

                Response.BinaryWrite(response.Movie[0].PosterImage);
            }
        }
    }
}
