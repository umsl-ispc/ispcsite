using System;
using System.Data;
using System.Data.SqlClient;
using System.Xml;
using System.Configuration;
using System.Reflection;

namespace Data
{
	/// <summary>
	/// This class provides generic methods for transactional data access. These
	/// methods include the ability to query the database and retrieve
	/// a DataTable or just execute a query. Notice that the queries can be SQL statements
	/// or stored procedures.
	/// </summary>
	/// <remarks>
	/// This abstract class can be used to quickly create a data access
	/// library for a project. In general, usage is as follows:<br/>
	/// <list type="number">
	/// <item>Add a reference to the SqlDataAccess assembly to your project.</item>
	/// <item>Create a new class that subclasses SqlDataAccessBase.</item>
	/// <item>Utilize the base constructor to set the connection string (see the constructor of this class for an example).</item>
	/// <item>Add methods to the new class for various data access activities.</item>
	/// <item>Use either the ExecuteNonQuery or FillDataTable methods to execute statements 
	/// against the database.</item>
	/// </list>
	/// Additional things to consider:
	/// <list type="bullet">
	/// <item>
	///	Connection opening and closing is handled automatically. 
	/// </item>
	/// <item>
	/// All input and output from this class uses the generic System.Data interfaces rather than
	/// the actual classes from the System.Data.SqlClient namespace. This should be transparant
	/// except for the use of DbType instead of SqlDbType in the CreateParameter method. For a list
	/// of SqlDbType to DbType conversions see <see href="http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpguide/html/cpconusingparameterswithdataadapters.asp"/>.
	/// </item>
	/// </list>
	/// </remarks>
	internal class SqlDataAccess
	{
		/// <summary>
		/// The connection string to the database.
		/// </summary>
		public string connectionString = "";
		
		/// <summary>
		/// A private variable to hold a reference to the Logger if found.
		/// </summary>
		private Type logger = null;

		/// <summary>
		/// The name to append to the log for events happening in this class.
		/// </summary>
		private string loggerName = "SqlDataAccessBase";

		/// <summary>
		/// The connection used throughout the lifetime of this class.
		/// </summary>
		private SqlConnection connection = null;

		/// <summary>
		/// The current transaction if one has been started.
		/// </summary>
		private SqlTransaction transaction = null;

		/// <summary>
		/// The name of the database server the connection string points to.
		/// </summary>
		protected string ServerName
		{
			get 
			{
				string result = "UNKNOWN";
				try
				{
					result = connection.DataSource;
				}
				catch{}
				return result;
			}
		}

		/// <summary>
		/// The default constructor for the DataAccessBase class. 
		/// </summary>
		/// <param name="connectionString">The connection string to use to connect to the database.</param>
		/// <remarks>
		/// Since this is a protected constructor, the connection string must be passed as such from the 
		/// extending class:
		/// <code>
		/// public ExtendingClass() : base("connection string here")
		/// {
		/// }
		/// </code>
		/// Typically, this is done by creating a private static method in the extending class that
		/// returns the connection string. A full example is as follows:
		/// <code>
		/// public ExtendingClass() : base(GetConnectionString())
		/// {
		/// }
		/// 
		/// private static string GetConnectionString()
		/// {
		///		string connectionString = "";
		///		//Any logic used to retrieve the connection string from the registry, etc...
		///		return connectionString;
		/// }
		/// </code>
		/// </remarks>
		public SqlDataAccess(string connectionString)
		{
			this.connectionString = connectionString;

			//We'll try to get a Logger object. If we can't, we'll just ignore all
			//logging statements. This section will work for executables.
//			try
//			{
//				Assembly assembly = Assembly.LoadFrom(AppDomain.CurrentDomain.BaseDirectory + "\\Logger.dll");
//				logger = assembly.GetType("AB.BEC.DRC.LoggerUtil.Logger");
//			}
//			catch(Exception ex)
//			{
//				Console.WriteLine(ex);
//			}
//
//			//If we still don't have a logger, try one more location. This section is for web applications.
//			if(logger == null)
//			{
//				try
//				{
//					Assembly assembly = Assembly.LoadFrom(AppDomain.CurrentDomain.BaseDirectory + "bin\\Logger.dll");
//					logger = assembly.GetType("AB.BEC.DRC.LoggerUtil.Logger");
//				}
//				catch(Exception ex)
//				{
//					Console.WriteLine(ex);
//				}
//			}
		}

		#region CreateParameter
		/// <summary>
		/// Creates an <see cref="System.Data.IDataParameter"/> based on the parameters passed to the method. This IDataParameter will be suitable
		/// to be passed back (as part of an array) to any of the methods in this class that require a parameters array.
		/// </summary>
		/// <param name="parameterName">The name of the parameter.</param>
		/// <param name="value">The parameter's value.</param>
		/// <param name="parameterType">A <see cref="System.Data.DbType"/> that indicates the type of the parameter.</param>
		/// <param name="parameterSize">The size of the parameter.</param>
		/// <returns>An <see cref="System.Data.IDataParameter"/>.</returns>
		/// <remarks>
		/// <list type="bullet">
		/// <item>
		/// This method creates Input parameters only. To pass a parameter as InputOutput, Output or ReturnValue, use a different
		/// overload of CreateParameter.
		/// </item>
		/// <item>
		/// This method takes a parameter of type DbType instead of SqlDbType to determine the type of the parameter. For a list
		/// of SqlDbType to DbType conversions see <see href="http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpguide/html/cpconusingparameterswithdataadapters.asp"/>.
		/// </item>
		/// </list>
		/// </remarks>
		public IDataParameter CreateParameter(string parameterName, object value, SqlDbType parameterType, int parameterSize)
		{
			return CreateParameter(parameterName, value, parameterType, parameterSize, ParameterDirection.Input);
		}


		/// <summary>
		/// Creates an <see cref="System.Data.IDataParameter"/> based on the parameters passed to the method. This IDataParameter will be suitable
		/// to be passed back (as part of an array) to any of the methods in this class that require a parameters array.
		/// </summary>
		/// <param name="parameterName">The name of the parameter.</param>
		/// <param name="value">The parameter's value.</param>
		/// <param name="parameterType">A <see cref="System.Data.DbType"/> that indicates the type of the parameter.</param>
		/// <param name="parameterSize">The size of the parameter.</param>
		/// <returns>An <see cref="System.Data.IDataParameter"/>.</returns>
		/// <remarks>
		/// <list type="bullet">
		/// <item>
		/// This method creates Input parameters only. To pass a parameter as InputOutput, Output or ReturnValue, use a different
		/// overload of CreateParameter.
		/// </item>
		/// <item>
		/// This method takes a parameter of type DbType instead of SqlDbType to determine the type of the parameter. For a list
		/// of SqlDbType to DbType conversions see <see href="http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpguide/html/cpconusingparameterswithdataadapters.asp"/>.
		/// </item>
		/// </list>
		/// </remarks>
//		public IDataParameter CreateParameter(string parameterName, object value, SqlDbType parameterType, int parameterSize)
//		{
//			return CreateParameter(parameterName, value, parameterType, parameterSize, ParameterDirection.Input);
//		}


		/// <summary>
		/// Creates an <see cref="System.Data.IDataParameter"/> based on the parameters passed to the method. This IDataParameter will be suitable
		/// to be passed back (as part of an array) to any of the methods in this class that require a parameters array.
		/// </summary>
		/// <param name="parameterName">The name of the parameter.</param>
		/// <param name="value">The parameter's value.</param>
		/// <param name="parameterType">A <see cref="System.Data.DbType"/> that indicates the type of the parameter.</param>
		/// <param name="parameterSize">The size of the parameter.</param>
		/// <param name="parameterDirection">Indicates whether the parameter is an input, output or return value.</param>
		/// <returns>An <see cref="System.Data.IDataParameter"/>.</returns>
		/// <remarks>
		/// This method takes a parameter of type DbType instead of SqlDbType to determine the type of the parameter. For a list
		/// of SqlDbType to DbType conversions see <see href="http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpguide/html/cpconusingparameterswithdataadapters.asp"/>.
		/// </remarks>
		public IDataParameter CreateParameter(string parameterName, object value, SqlDbType parameterType, int parameterSize, ParameterDirection parameterDirection)
		{
			if(!parameterName.StartsWith("@")) 
			{
				parameterName = "@" + parameterName;
			}
			
			SqlParameter parameter = new SqlParameter(parameterName, value);
			parameter.SqlDbType = parameterType;
			parameter.Size = parameterSize;
			parameter.Direction = parameterDirection;

			return (IDataParameter) parameter;
		}

		/// <summary>
		/// Creates an <see cref="System.Data.IDataParameter"/> based on the parameters passed to the method. This IDataParameter will be suitable
		/// to be passed back (as part of an array) to any of the methods in this class that require a parameters array.
		/// </summary>
		/// <param name="parameterName">The name of the parameter.</param>
		/// <param name="value">The parameter's value.</param>
		/// <param name="parameterType">A <see cref="System.Data.DbType"/> that indicates the type of the parameter.</param>
		/// <returns>An <see cref="System.Data.IDataParameter"/>.</returns>
		/// <remarks>
		/// <list type="bullet">
		/// <item>
		/// This method creates Input parameters only. To pass a parameter as InputOutput, Output or ReturnValue, use a different
		/// overload of CreateParameter.
		/// </item>
		/// <item>
		/// This method takes a parameter of type DbType instead of SqlDbType to determine the type of the parameter. For a list
		/// of SqlDbType to DbType conversions see <see href="http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpguide/html/cpconusingparameterswithdataadapters.asp"/>.
		/// </item>
		/// </list>
		/// </remarks>
		public IDataParameter CreateParameter(string parameterName, object value, SqlDbType parameterType)
		{
			return CreateParameter(parameterName, value, parameterType, ParameterDirection.Input);
		}

		/// <summary>
		/// Creates an <see cref="System.Data.IDataParameter"/> based on the parameters passed to the method. This IDataParameter will be suitable
		/// to be passed back (as part of an array) to any of the methods in this class that require a parameters array.
		/// </summary>
		/// <param name="parameterName">The name of the parameter.</param>
		/// <param name="value">The parameter's value.</param>
		/// <param name="parameterType">A <see cref="System.Data.DbType"/> that indicates the type of the parameter.</param>
		/// <param name="parameterDirection">Indicates whether the parameter is an input, output or return value.</param>
		/// <returns>An <see cref="System.Data.IDataParameter"/>.</returns>
		/// <remarks>
		/// This method takes a parameter of type DbType instead of SqlDbType to determine the type of the parameter. For a list
		/// of SqlDbType to DbType conversions see <see href="http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpguide/html/cpconusingparameterswithdataadapters.asp"/>.
		/// </remarks>
		public IDataParameter CreateParameter(string parameterName, object value, SqlDbType parameterType, ParameterDirection parameterDirection)
		{
			if(!parameterName.StartsWith("@"))
			{
				parameterName = "@" + parameterName;
			}

			SqlParameter parameter = new SqlParameter(parameterName, value);
			parameter.SqlDbType = parameterType;
			parameter.Direction = parameterDirection;

			return (IDataParameter) parameter;
		}
			
		/// <summary>
		/// Creates an <see cref="System.Data.IDataParameter"/> based on the parameters passed to the method. This IDataParameter will be suitable
		/// to be passed back (as part of an array) to any of the methods in this class that require a parameters array.
		/// </summary>
		/// <param name="parameterName">The name of the parameter.</param>
		/// <param name="value">The parameter's value.</param>
		/// <returns>An <see cref="System.Data.IDataParameter"/>.</returns>
		/// <remarks>
		/// This method creates Input parameters only. To pass a parameter as InputOutput, Output or ReturnValue, use a different
		/// overload of CreateParameter.
		/// </remarks>
		public IDataParameter CreateParameter(string parameterName, object value)
		{
			if(!parameterName.StartsWith("@"))
			{
				parameterName = "@" + parameterName;
			}

			SqlParameter parameter = new SqlParameter(parameterName, value);

			return (IDataParameter) parameter;
		}
		#endregion
	
		#region Transaction Support
		/// <summary>
		/// Begins a database transaction. Each ExecuteNonQuery and FillDataTable method called after this
		/// method has been called will be enrolled in the transaction.
		/// </summary>
		public void BeginTransaction()
		{
			if(transaction != null)
			{
//				throw new SqlDataAccessBase.TransactionAlreadyBegunException();
			}
			OpenConnectionIfNeeded();
			transaction = connection.BeginTransaction();
		}

		/// <summary>
		/// Commits the existing transaction (if there is one).
		/// </summary>
		public void CommitTransaction()
		{
			if(transaction != null)
			{
				transaction.Commit();
				transaction = null;
			}
			CloseConnectionIfNeeded();
		}

		/// <summary>
		/// Rolls back the existing transaction (if there is one).
		/// </summary>
		public void RollbackTransaction()
		{
			if(transaction != null)
			{
				transaction.Rollback();
				transaction = null;
			}
			CloseConnectionIfNeeded();
		}

		/// <summary>
		/// Thrown when BeginTransaction() is called on the SqlDataAccessBase class after it has already
		/// been called once but before CommitTransaction() or RollbackTransaction() has been called.
		/// </summary>
		public class TransactionAlreadyBegunException : ApplicationException
		{
			/// <summary>
			/// Default constructor.
			/// </summary>
			public TransactionAlreadyBegunException() : base()
			{
			}
		}
		#endregion

		#region ExecuteScalar
		public int ExecuteScalar(string sql, IDataParameter[] parameters, CommandType commandType)
		{
			OpenConnectionIfNeeded();
			SqlCommand command = new SqlCommand(sql, connection, transaction);
			command.CommandType = commandType;
			
			if(parameters != null)
			{
				for(int i=0; i<parameters.Length; i++)
				{
					command.Parameters.Add(parameters[i]);
				}
			}
			return int.Parse(command.ExecuteScalar().ToString());
		}
		#endregion



		#region ExecuteNonQuery
		/// <summary>
		/// Runs a SQL statement or a stored procedure.
		/// </summary>
		/// <param name="sql">The SQL statment or stored procedure name to run.</param>
		/// <param name="parameters">Any parameters required for the SQL statement or stored procedure.  Pass null if there are no parameters needed.</param>
		/// <param name="commandType">Indicates the type of statement represented by the sql parameter.</param>
		/// <returns>The number of rows affected if SET NOCOUNT is OFF, -1 otherwise.</returns>
		/// <example>
		/// This example shows how to use ExecuteNonQuery to execute a stored procedure.
		/// <code>
		///	IDataParameter[] parameters = new IDataParameter[2];
		///	parameters[0] = CreateParameter("@Param1", 12, DbType.Int32);
		///	parameters[1] = CreateParameter("@Param2", "Hello world!", DbType.String, 30);
		///	ExecuteNonQuery("spMyStoredProcedure", parameters, CommandType.StoredProcedure);
		/// </code>
		/// Similarly, this method can be used to run ad hoc parameterized Sql statements:
		/// <code>
		/// IDataParameter[] parameters = new IDataParameter[1];
		/// parameters[0] = CreateParameter("@Param1", 12, DbType.Int32);
		/// ExecuteNonQuery("DELETE FROM User WHERE UserID = @Param1", parameters, CommandType.Text);
		/// </code>
		/// </example>
		public int ExecuteNonQuery(string sql, IDataParameter[] parameters, CommandType commandType)
		{
			return ExecuteNonQuery(sql, parameters, commandType, -1);
		}

		/// <summary>
		/// Runs a SQL statement or a stored procedure.
		/// </summary>
		/// <param name="sql">The SQL statment or stored procedure name to run.</param>
		/// <param name="parameters">Any parameters required for the SQL statement or stored procedure.  Pass null if there are no parameters needed.</param>
		/// <param name="commandType">Indicates the type of statement represented by the sql parameter.</param>
		/// <param name="commandTimeoutInSeconds">The amount of time (in seconds) to wait before aborting the sql statement.</param>
		/// <returns>The number of rows affected if SET NOCOUNT is OFF, -1 otherwise.</returns>
		/// <example>
		/// This example shows how to use ExecuteNonQuery to execute a stored procedure.
		/// <code>
		///	IDataParameter[] parameters = new IDataParameter[2];
		///	parameters[0] = CreateParameter("@Param1", 12, DbType.Int32);
		///	parameters[1] = CreateParameter("@Param2", "Hello world!", DbType.String, 30);
		///	ExecuteNonQuery("spMyStoredProcedure", parameters, CommandType.StoredProcedure);
		/// </code>
		/// Similarly, this method can be used to run ad hoc parameterized Sql statements:
		/// <code>
		/// IDataParameter[] parameters = new IDataParameter[1];
		/// parameters[0] = CreateParameter("@Param1", 12, DbType.Int32);
		/// ExecuteNonQuery("DELETE FROM User WHERE UserID = @Param1", parameters, CommandType.Text);
		/// </code>
		/// </example>
		public int ExecuteNonQuery(string sql, IDataParameter[] parameters, CommandType commandType, int commandTimeoutInSeconds)
		{
			int result = -1;
			try
			{
				OpenConnectionIfNeeded();
				SqlCommand command = new SqlCommand(sql, connection, transaction);
				command.CommandType = commandType;
				if(commandTimeoutInSeconds != -1)
				{
					command.CommandTimeout = commandTimeoutInSeconds;
				}
				if(parameters != null)
				{
					for(int i=0; i<parameters.Length; i++)
					{
						command.Parameters.Add(parameters[i]);
					}
				}

				LogData("ExecuteNonQuery: " + GenerateSql(command), loggerName);
				DateTime startTime = DateTime.Now;
				startTime = DateTime.Now;
				result = command.ExecuteNonQuery();
				LogData("ExecuteNonQueryFinished(" + ((TimeSpan) DateTime.Now.Subtract(startTime)).TotalMilliseconds + "): " + GenerateSql(command), loggerName);
			}
			finally
			{
				CloseConnectionIfNeeded();
			}
			return result;
		}
		#endregion

		#region FillDataTable
		/// <summary>
		/// Runs a SQL statement or a stored procedure and returns a DataTable with the results.
		/// </summary>
		/// <param name="sql">The SQL statment or stored procedure name to run.</param>
		/// <param name="parameters">Any parameters required for the SQL statement or stored procedure.  Pass null if there are no parameters needed.</param>
		/// <param name="commandType">Indicates the type of statement represented by the sql parameter.</param>
		/// <example>
		/// This example shows how to use FillDataTable to execute a stored procedure and retrive the results.
		/// <code>
		///	IDataParameter[] parameters = new IDataParameter[2];
		///	parameters[0] = CreateParameter("@Param1", 12, DbType.Int32);
		///	parameters[1] = CreateParameter("@Param2", "Hello world!", DbType.String, 30);
		///	DataTable dataTable = FillDataTable("spMyStoredProcedure", parameters, CommandType.StoredProcedure);
		/// </code>
		/// Similarly, this method can be used to run ad hoc parameterized Sql statements:
		/// <code>
		/// IDataParameter[] parameters = new IDataParameter[1];
		/// parameters[0] = CreateParameter("@Param1", 12, DbType.Int32);
		/// DataTable dataTable = FillDataTable("DELETE FROM User WHERE UserID = @Param1", parameters, CommandType.Text);
		/// </code>
		/// </example>
		public DataTable FillDataTable(string sql, IDataParameter[] parameters, CommandType commandType)
		{
			return FillDataTable(sql, parameters, commandType, -1);
		}

		/// <summary>
		/// Runs a SQL statement or a stored procedure and returns a DataTable with the results.
		/// </summary>
		/// <param name="sql">The SQL statment or stored procedure name to run.</param>
		/// <param name="parameters">Any parameters required for the SQL statement or stored procedure.  Pass null if there are no parameters needed.</param>
		/// <param name="commandType">Indicates the type of statement represented by the sql parameter.</param>
		/// <param name="commandTimeoutInSeconds">The amount of time (in seconds) to wait before aborting the sql statement.</param>
		/// <example>
		/// This example shows how to use FillDataTable to execute a stored procedure and retrive the results.
		/// <code>
		///	IDataParameter[] parameters = new IDataParameter[2];
		///	parameters[0] = CreateParameter("@Param1", 12, DbType.Int32);
		///	parameters[1] = CreateParameter("@Param2", "Hello world!", DbType.String, 30);
		///	DataTable dataTable = FillDataTable("spMyStoredProcedure", parameters, CommandType.StoredProcedure);
		/// </code>
		/// Similarly, this method can be used to run ad hoc parameterized Sql statements:
		/// <code>
		/// IDataParameter[] parameters = new IDataParameter[1];
		/// parameters[0] = CreateParameter("@Param1", 12, DbType.Int32);
		/// DataTable dataTable = FillDataTable("DELETE FROM User WHERE UserID = @Param1", parameters, CommandType.Text);
		/// </code>
		/// </example>
		public DataTable FillDataTable(string sql, IDataParameter[] parameters, CommandType commandType, int commandTimeoutInSeconds)
		{
			DataTable result = new DataTable();

			try
			{
				OpenConnectionIfNeeded();
				SqlCommand command = new SqlCommand(sql, connection, transaction);
				SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
				command.CommandType = commandType;
				if(commandTimeoutInSeconds != -1)
				{
					command.CommandTimeout = commandTimeoutInSeconds;
				}
				if(parameters != null)
				{
					for(int i=0; i<parameters.Length; i++)
					{
						command.Parameters.Add(parameters[i]);
					}
				}
				LogData("FillDataTable: " + GenerateSql(command), loggerName);
				DateTime startTime = DateTime.Now;
				dataAdapter.Fill(result);
				LogData("FillDataTableFinished(" + ((TimeSpan) DateTime.Now.Subtract(startTime)).TotalMilliseconds + "): " + GenerateSql(command), loggerName);
			}
			finally
			{
				CloseConnectionIfNeeded();
			}
			return result;
		}

		/// <summary>
		/// Runs a SQL query and fills a DataSet object with the results
		/// </summary>
		/// <param name="sql">The SQL command to be excuted</param>
		/// <param name="parameters">A parameter array for the query</param>
		/// <param name="commandType">The type of command to execute</param>
		/// <returns>Returns a DataSet object containing the data from the SQL query</returns>
		public DataSet FillDataSet(string sql, IDataParameter[] parameters, CommandType commandType)
		{
			DataSet result = new DataSet();

			try
			{
				OpenConnectionIfNeeded();
				SqlCommand command = new SqlCommand(sql, connection, transaction);
				SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
				command.CommandType = commandType;
				
				if(parameters != null)
				{
					for(int i=0; i<parameters.Length; i++)
					{
						command.Parameters.Add(parameters[i]);
					}
				}
				LogData("FillDataTable: " + GenerateSql(command), loggerName);
				DateTime startTime = DateTime.Now;
				dataAdapter.Fill(result);
				LogData("FillDataTableFinished(" + ((TimeSpan) DateTime.Now.Subtract(startTime)).TotalMilliseconds + "): " + GenerateSql(command), loggerName);
			}
			finally
			{
				CloseConnectionIfNeeded();
			}
			return result;
		}
		#endregion

		#region Connection Management Methods
		/// <summary>
		/// Opens a connection to the database if needed.
		/// </summary>
		private void OpenConnectionIfNeeded()
		{
			if(connection == null)
			{
				connection = new SqlConnection(connectionString);
				connection.Open();
			}
		}

		/// <summary>
		/// Closes the connection if it is open and is not an outstanding transaction.
		/// </summary>
		private void CloseConnectionIfNeeded()
		{
			if(transaction == null)
			{
				if ( connection != null)
				{
					if(connection.State != System.Data.ConnectionState.Closed)
					{
						connection.Close();
					}
					connection = null;
				}
			}
		}
		#endregion

		#region Logging Methods
		/// <summary>
		/// Uses the Logger type to log a data message.
		/// </summary>
		/// <param name="message">The message to append to the log.</param>
		/// <param name="name">The name to identify the message with.</param>
		private void LogData(string message, string name)
		{
			bool doLogging = true;
			
			//First, check to see if we even have a logger object.
			if(logger == null)
			{
				doLogging = false;
			}
			else
			{
				//If we have one, check to see if data logging is enabled.
				if(!(bool) logger.GetProperty("DataEnabled").GetValue(logger, null))
				{
					doLogging = false;
				}
			}
	
			if(doLogging)
			{
				MethodInfo methodInfo = logger.GetMethod("Data", new Type[]{typeof(string), typeof(string)});
				methodInfo.Invoke(logger, new object[] {message, name});
			}
		}
		#endregion

		#region Misc
		/// <summary>
		/// This method prepares a string for database activity by replacing
		/// special characters with the database equivalent. This method is <b>NOT</b> called
		/// automatically by any of the RunSql* methods. The caller is responsible for using
		/// it if necessary.
		/// </summary>
		/// <remarks>This method is useful for parameters of type String. It will replace special
		/// characters with their Sql equivalent (for example, ' is replaced with '').</remarks>
		/// <param name="toPrep">The string to prepare.</param>
		/// <returns>The prepared string.</returns>
		public string PrepForDB(string toPrep)
		{
			return toPrep.Replace("'", "''");
		}

		/// <summary>
		/// Returns a default value if the specified value is null or DBNull.Value.
		/// </summary>
		/// <param name="fieldValue">The field to compare to null and DBNull.Value.</param>
		/// <param name="defaultValue">The value to return if fieldValue is null or DBNull.Value.</param>
		/// <returns>The data in fieldValue if it is not null and not DBNull.Value, the data in default
		/// value otherwise.</returns>
		public object DefaultIfNull( object fieldValue, object defaultValue)
		{
			if (fieldValue == null || fieldValue == System.DBNull.Value)
			{
				return defaultValue;
			}
			else
			{
				return fieldValue;
			}
		}

		/// <summary>
		/// Converts a SqlCommand into the text equivalent. For example, if the command represents a stored procedure, this method
		/// will return the syntax of the call, with the values of the parameters shown.
		/// </summary>
		/// <param name="command">The commant that is to be converted to text.</param>
		/// <returns>A string representation of the command.</returns>
		private string GenerateSql(SqlCommand command)
		{
			string result = "";

			result += command.CommandText + " ";
			if(command.CommandType == CommandType.StoredProcedure)
			{
				foreach(SqlParameter p in command.Parameters)
				{
					result += p.ParameterName + ", ";
				}
				if(result.EndsWith(", "))
				{
					result = result.Substring(0, result.Length - 2);
				}
			}
			foreach(SqlParameter p in command.Parameters)
			{
				if(p.SqlDbType == SqlDbType.NChar || p.SqlDbType == SqlDbType.NText || p.SqlDbType == SqlDbType.NVarChar || p.SqlDbType == SqlDbType.Char || p.SqlDbType == SqlDbType.Text || p.SqlDbType == SqlDbType.VarChar)
				{
					if(p.Value == null || p.Value == DBNull.Value)
					{
						result = result.Replace(p.ParameterName, "null");
					}
					else
					{
						result = result.Replace(p.ParameterName, "'" + PrepForDB(p.Value.ToString()) + "'");
					}
				}
				else
				{
					if(p.Value == null || p.Value == DBNull.Value)
					{
						result = result.Replace(p.ParameterName, "null");
					}
					else
					{
						result = result.Replace(p.ParameterName, p.Value.ToString());
					}
				}
			}
			return result;
		}
		#endregion
	}
}
