using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for GetMovieResponse
/// </summary>
[Serializable]
public class GetMovieResponse
{
    /// <summary>
    /// Constructor method
    /// </summary>
	public GetMovieResponse()
	{
	}

    private Movie[] _movie = new Movie[0];
    private Message _message = new Message();

    public global::Movie[] Movie
    {
        get
        {
            return _movie;
        }
        set
        {
            _movie = value;
        }
    }

    public Message Message
    {
        get
        {
            return _message;
        }
        set
        {
            _message = value;
        }
    }
}
