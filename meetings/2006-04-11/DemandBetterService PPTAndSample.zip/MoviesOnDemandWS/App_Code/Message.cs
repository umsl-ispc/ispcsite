using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[Serializable()]
public class Message
{
    public Message()
    {
    }

    private string _content = string.Empty;
    private MessageType _messageType = MessageType.Common;

    /// <summary>
    /// The content of the message
    /// </summary>
    public string Content
    {
        get
        {
            return _content;
        }
        set
        {
            _content = value;
        }
    }

    public global::MessageType MessageType
    {
        get
        {
            return _messageType;
        }
        set
        {
            _messageType = value;
        }
    }
}
