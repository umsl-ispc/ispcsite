using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[Serializable]
public class Person
{
    public Person()
    {
    }

    private string _firstName = string.Empty;
    private string _lastName = string.Empty;
    private string _id = string.Empty;

    /// <summary>
    /// The actor's first name
    /// </summary>
    public string FirstName
    {
        get
        {
            return _firstName;
        }
        set
        {
            _firstName = value;
        }
    }

    /// <summary>
    /// The actor's last name
    /// </summary>
    public string LastName
    {
        get
        {
            return _lastName;
        }
        set
        {
            _lastName = value;
        }
    }

    /// <summary>
    /// The unique identifier for a person in the system
    /// </summary>
    public string ID
    {
        get
        {
            return _id;
        }
        set
        {
            _id = value;
        }
    }
}
