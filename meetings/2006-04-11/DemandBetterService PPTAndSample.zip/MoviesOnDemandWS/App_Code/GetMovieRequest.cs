using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for GetMovie
/// </summary>
[Serializable]
public class GetMovieRequest
{
    /// <summary>
    /// Constructor method
    /// </summary>
	public GetMovieRequest()
	{
	}

    private string _movieID = string.Empty;
    private short _getAll = 1;

    /// <summary>
    /// The unique identifier for a specific movie in the system.
    /// </summary>
    public string MovieID
    {
        get
        {
            return _movieID;
        }
        set
        {
            _movieID = value;
        }
    }

    public short GetAll
    {
        get
        {
            return _getAll;
        }
        set
        {
            _getAll = value;
        }
    }

}
