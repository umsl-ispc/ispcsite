using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;


[Serializable()]
public class Account
{
    public Account()
    {
    }

    private string _id = string.Empty;
    private string _username = string.Empty;
    private string _password = string.Empty;
    private Address[] _address = new Address[0];
    private Customer _customer = new Customer();

    /// <summary>
    /// The unique identifier of the account
    /// </summary>
    public string ID
    {
        get
        {
            return _id;
        }
        set
        {
            _id = value;
        }
    }

    /// <summary>
    /// The address information for this account
    /// </summary>
    public Address[] Address
    {
        get
        {
            return _address;
        }
        set
        {
            _address = value;
        }
    }

    public global::Customer Customer
    {
        get
        {
            return _customer;
        }
        set
        {
            _customer = value;
        }
    }

    /// <summary>
    /// The username by which the customer can access the account information
    /// </summary>
    public string Username
    {
        get
        {
            return _username;
        }
        set
        {
            _username = value;
        }
    }

    /// <summary>
    /// The password by which the customer can access the account
    /// </summary>
    public string Password
    {
        get
        {
            return _password;
        }
        set
        {
            _password = value;
        }
    }
}
