using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Data;

/// <summary>
/// Summary description for MovieData
/// </summary>
internal class MovieData : SqlDataAccess
{
    public MovieData(string connectionString) : base(connectionString)
    {
    }

    internal Movie[] GetMovie(string movieID, short getAll)
    {
        IDataParameter[] parameter = null;

        //The dbo.GetMovie stored procedure provides the ability to reteive a single or a list of movies depending on the format of the
        //request. This logic routine determines the scope of the request.
        if (movieID.Equals(string.Empty))
        {
            parameter = new IDataParameter[1];
            parameter[0] = this.CreateParameter("@GetAll", getAll, SqlDbType.TinyInt);
        }
        else
        {
            Guid id = new Guid(movieID);
            parameter = new IDataParameter[2];
            parameter[0] = this.CreateParameter("@MovieID", id, SqlDbType.UniqueIdentifier);
            parameter[1] = this.CreateParameter("@GetAll", getAll, SqlDbType.TinyInt);
        }

        DataTable dt = null;

        try
        {
            //Call to the SqlDataAccess class and load a data table with the results
            dt = this.FillDataTable("dbo.GetMovie", parameter, CommandType.StoredProcedure);

            Movie[] movies = null;
            Movie movie = null;

            if (dt.Rows.Count > 0)
            {
                movies = new Movie[dt.Rows.Count];
                DataRow row;
                int counter = 0;

                //Since we got one or movies back from the stored procedure, load each individual Movie object into the array
                while (counter < dt.Rows.Count)
                {
                    row = dt.Rows[counter];
                    movie = new Movie();

                    movie.ID = row["MovieID"].ToString();
                    movie.Title = row["Title"].ToString();
                    movie.FileName = row["FileName"].ToString();
                    movie.FileSize = float.Parse(row["FileSize"].ToString());
                    movie.DateOfRelease = row["DateOfRelease"].ToString();
                    movie.Director = new Director();
                    movie.Director.ID = row["DirectorID"].ToString();
                    movie.Director.FirstName = row["FirstName"].ToString();
                    movie.Director.LastName = row["LastName"].ToString();
                    movie.PosterImage = (byte[])row["PosterImage"];

                    movies[counter] = movie;
                    counter += 1;
                }
            }
            else
            {
                //If the execution of the stored procedure yielded no results, then return a Movie array with 0 items.
                //This simple act will help avoid NullReferenceException errors onthe consumer end. The consumer can check
                //the length of the array.
                movies = new Movie[0];
            }

            return movies;
        }

        //We implement the finally clause to make sure we call the Dispose() method on the DataTable object.
        //There is no catch bloack because we are actually handling the exception higher up the call stack
        finally
        {
            if(dt != null)
                dt.Dispose();
        }
    }
}
