using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Web.Configuration;

[WebService(Namespace = "http://MoviesOnDemandWS.com")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class MoviesOnDemand : System.Web.Services.WebService
{
    public MoviesOnDemand () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    /// <summary>
    /// Retrieves the necessary information to view a movie.
    /// </summary>
    /// <param name="request">A request message with the necessary information to complete the request</param>
    [WebMethod()]
    public GetMovieResponse GetMovie(GetMovieRequest request)
    {
        GetMovieResponse response = new GetMovieResponse();
        response.Message = new Message();

        try
        {
            MovieData movieData = new MovieData(WebConfigurationManager.ConnectionStrings["MoviesOnDemand"].ConnectionString);
            response.Movie = movieData.GetMovie(request.MovieID, request.GetAll);

            if (response.Movie.Length.Equals(0))
            {
                response.Message.MessageType = MessageType.Alert;
                response.Message.Content = "No movies were found.";
            }
        }

        catch (Exception ex)
        {
            response.Message.MessageType = MessageType.Exception;
            response.Message.Content = "An error occured while retrieving the movie. Here are the details:<br>" + ex.Message + "<br>" + ex.Source + "<br>" + ex.StackTrace;
        }

        return response;
    }

    /// <summary>
    /// Authenticates a user account to use the movies on demand service
    /// </summary>
    /// <param name="request">An AuthenticateRequest object containing the authentication credentials</param>
    /// <returns>An AuthenticateResponse object containing the account information and request results</returns>
    [WebMethod()]
    public AuthenticateResponse Authenticate(AuthenticateRequest request)
    {
        AuthenticateResponse response = new AuthenticateResponse();
        response.Message = new Message();

        try
        {
            CustomerData customerData = new CustomerData(WebConfigurationManager.ConnectionStrings["MoviesOnDemand"].ConnectionString);
            response.Account = customerData.AuthenticateUser(request.Username, request.Password);

            if (!response.Account.ID.Equals(string.Empty))
            {
                response.Result = true;
                response.Message.MessageType = MessageType.Common;
                response.Message.Content = "Authentication attempt was successful.";
            }
            else
            {
                response.Result = false;
                response.Message.MessageType = MessageType.Alert;
                response.Message.Content = "Username and password combination not found";
            }
        }

        catch (Exception ex)
        {
            response.Result = false;
            response.Message.MessageType = MessageType.Exception;
            response.Message.Content = "An exception took place during the authentication request. The details are:<br>" + ex.Message + "<br>" + ex.Source + "<br>" + ex.StackTrace;
        }

        return response;
    }

    
    
}
