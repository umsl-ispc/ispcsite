using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[Serializable()]
public class Movie
{
    /// <summary>
    /// Constructor method
    /// </summary>
    public Movie()
    {
    }

    private string _title = string.Empty;
    private Director _director = new Director();
    private Actor[] _cast = new Actor[0];
    private string _fileName = string.Empty;
    private float _fileSize = 0;
    private string _dateOfRelease = string.Empty;
    private string _id = string.Empty;
    private byte[] _posterImage = new byte[0];

    /// <summary>
    /// The name of the movie
    /// </summary>
    public string Title
    {
        get
        {
            return _title;
        }
        set
        {
            _title = value;
        }
    }

    /// <summary>
    /// A collection of Director objects with information about the movie's director(s)
    /// </summary>
    public Director Director
    {
        get
        {
            return _director;
        }
        set
        {
            _director = value;
        }
    }

    /// <summary>
    /// A collection of Actor objects containing the cast members of the movie
    /// </summary>
    public Actor[] Cast
    {
        get
        {
            return _cast;
        }
        set
        {
            _cast = value;
        }
    }

    /// <summary>
    /// The name of the digital movie file on the server
    /// </summary>
    public string FileName
    {
        get
        {
            return _fileName;
        }
        set
        {
            _fileName = value;
        }
    }

    /// <summary>
    /// The size of the digital movie file on the server
    /// </summary>
    public float FileSize
    {
        get
        {
            return _fileSize;
        }
        set
        {
            _fileSize = value;
        }
    }

    /// <summary>
    /// The date that the movie was originally released
    /// </summary>
    public string DateOfRelease
    {
        get
        {
            return _dateOfRelease;
        }
        set
        {
            _dateOfRelease = value;
        }
    }

    /// <summary>
    /// The unique identifier for a movie in the system
    /// </summary>
    public string ID
    {
        get
        {
            return _id;
        }
        set
        {
            _id = value;
        }
    }

    /// <summary>
    /// The image data for the poster for the movie
    /// </summary>
    public byte[] PosterImage
    {
        get
        {
            return _posterImage;
        }
        set
        {
            _posterImage = value;
        }
    }
}
