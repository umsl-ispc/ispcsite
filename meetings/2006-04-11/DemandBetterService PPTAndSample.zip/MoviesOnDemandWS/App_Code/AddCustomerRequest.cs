using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[Serializable()]
public class AddAccountRequest
{
    public AddAccountRequest()
    {
    }

    private Account _account = new Account();

    public global::Account Account
    {
        get
        {
            return _account;
        }
        set
        {
            _account = value;
        }
    }
}
