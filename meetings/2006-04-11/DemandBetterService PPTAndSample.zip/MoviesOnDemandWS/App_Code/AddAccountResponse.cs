using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[Serializable()]
public class AddAccountResponse
{
    public AddAccountResponse()
    {
    }

    private string _accountID = string.Empty;
    private Message _message = new Message();


    /// <summary>
    /// The unique identifier of the newly created account
    /// </summary>
    public string AccountID
    {
        get
        {
            return _accountID;
        }
        set
        {
            _accountID = value;
        }
    }

    public global::Message Message
    {
        get
        {
            return _message;
        }
        set
        {
            _message = value;
        }
    }
}
