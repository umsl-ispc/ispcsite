using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

public class GetMovieListRequest
{
    /// <summary>
    /// Constructor method
    /// </summary>
    public GetMovieListRequest()
    {
        throw new System.NotImplementedException();
    }
}
