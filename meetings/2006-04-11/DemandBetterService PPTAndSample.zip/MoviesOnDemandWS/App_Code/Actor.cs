using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[Serializable]
public class Actor : global::Person
{
    /// <summary>
    /// Constructor method
    /// </summary>
    public Actor()
    {
    }
}
