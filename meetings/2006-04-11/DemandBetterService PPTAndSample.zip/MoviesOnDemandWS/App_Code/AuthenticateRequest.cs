using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[Serializable()]
public class AuthenticateRequest
{
    public AuthenticateRequest()
    {
    }

    private string _username = string.Empty;
    private string _password = string.Empty;

    /// <summary>
    /// The username for the account to be authenticated
    /// </summary>
    public string Username
    {
        get
        {
            return _username;
        }
        set
        {
            _username = value;
        }
    }

    /// <summary>
    /// The encrypted password for the account to be authenticated
    /// </summary>
    public string Password
    {
        get
        {
            return _password;
        }
        set
        {
            _password = value;
        }
    }
}
