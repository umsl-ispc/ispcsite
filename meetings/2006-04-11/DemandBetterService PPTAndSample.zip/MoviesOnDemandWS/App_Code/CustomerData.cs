using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Data;

/// <summary>
/// Summary description for CustomerData
/// </summary>
internal class CustomerData : SqlDataAccess
{
    public CustomerData(string connectionString) : base(connectionString)
    {
    }

    internal Account AuthenticateUser(string username, string password)
    {
        IDataParameter[] parameters = new IDataParameter[2];
        parameters[0] = this.CreateParameter("@Username", username, SqlDbType.VarChar, 100);
        parameters[1] = this.CreateParameter("@Password", password, SqlDbType.VarChar, 100);

        DataTable dt = null;

        try
        {
            dt = this.FillDataTable("dbo.AuthenticateUser", parameters, CommandType.StoredProcedure);

            Account account = new Account();

            //This logic statement assumes that only one row of data will be returned and that it will match the user account information.
            //Proper database design is essential here to ensure that each user of the application will only have one account in the system.
            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];
                account.ID = row["AccountID"].ToString();
                account.Username = username;
                account.Password = password;
                account.Customer = new Customer();
                account.Customer.FirstName = row["FirstName"].ToString();
                account.Customer.LastName = row["LastName"].ToString();
                account.Customer.ID = row["UserID"].ToString();
            }

            return account;
        }


        //We implement the finally clause to make sure we call the Dispose() method on the DataTable object.
        //There is no catch bloack because we are actually handling the exception higher up the call stack
        finally
        {
            if(dt != null)
                dt.Dispose();
        }
    }

}
