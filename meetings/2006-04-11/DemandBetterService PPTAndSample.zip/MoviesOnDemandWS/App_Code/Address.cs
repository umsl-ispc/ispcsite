using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[Serializable]
public class Address
{
    public Address()
    {
    }

    private string _streetAddress = string.Empty;
    private string _city = string.Empty;
    private string _state = string.Empty;
    private string _postalCode = string.Empty;
    private string _country = string.Empty;
    private AddressType _addressType = AddressType.Home;
    
    /// <summary>
    /// The street address of the person
    /// </summary>
    public string StreetAddress
    {
        get
        {
            return _streetAddress;
        }
        set
        {
            _streetAddress = value;
        }
    }

    /// <summary>
    /// The city portion of the person's address
    /// </summary>
    public string City
    {
        get
        {
            return _city;
        }
        set
        {
            _city = value;
        }
    }

    /// <summary>
    /// The state portion of the person's address
    /// </summary>
    public string State
    {
        get
        {
            return _state;
        }
        set
        {
            _state = value;
        }
    }

    /// <summary>
    /// The postal code portion of the person's address
    /// </summary>
    public string PostalCode
    {
        get
        {
            return _postalCode;
        }
        set
        {
            _postalCode = value;
        }
    }

    /// <summary>
    /// The country portion of the person's address
    /// </summary>
    public string Country
    {
        get
        {
            return _country;
        }
        set
        {
            _country = value;
        }
    }

    public global::AddressType AddressType
    {
        get
        {
            return _addressType;
        }
        set
        {
            _addressType = value;
        }
    }
}
