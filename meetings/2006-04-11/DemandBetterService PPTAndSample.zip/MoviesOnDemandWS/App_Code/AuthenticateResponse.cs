using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[Serializable()]
public class AuthenticateResponse
{
    public AuthenticateResponse()
    {
    }

    private Account _account = new Account();
    private Message _message = new Message();
    private bool _result = false;

    public global::Account Account
    {
        get
        {
            return _account;
        }
        set
        {
            _account = value;
        }
    }

    public global::Message Message
    {
        get
        {
            return _message;
        }
        set
        {
            _message = value;
        }
    }

    public bool Result
    {
        get
        {
            return _result;
        }
        set
        {
            _result = value;
        }
    }
}
