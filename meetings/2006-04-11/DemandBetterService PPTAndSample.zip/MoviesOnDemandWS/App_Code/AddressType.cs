using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[Serializable()]
public enum AddressType
{
    Billing = 1,
    Shipping = 2,
    Home = 3,
}
